import { useState, useEffect } from 'react';

const PERFUMES = [
  {
    id: 1,
    name: "BLESS NOIR",
    subtitle: "Inspired by Oud & Amber",
    price: 450,
    notes: "Oud • Amber • Musk",
    image: "https://images.pexels.com/photos/11216321/pexels-photo-11216321.jpeg?auto=compress&cs=tinysrgb&w=800",
    bestseller: true,
    intensity: "Eau de Parfum • 50ml"
  },
  {
    id: 2,
    name: "GOLDEN AURA",
    subtitle: "Inspired by Vanilla & Saffron",
    price: 420,
    notes: "Saffron • Vanilla • Sandalwood",
    image: "https://images.pexels.com/photos/13882813/pexels-photo-13882813.jpeg?auto=compress&cs=tinysrgb&w=800",
    bestseller: false,
    intensity: "Eau de Parfum • 50ml"
  },
  {
    id: 3,
    name: "DIVINE ROSE",
    subtitle: "Inspired by Roses & Musk",
    price: 380,
    notes: "Damascus Rose • Musk • Patchouli",
    image: "https://images.pexels.com/photos/10924522/pexels-photo-10924522.jpeg?auto=compress&cs=tinysrgb&w=800",
    bestseller: true,
    intensity: "Oil Based • 30ml"
  },
  {
    id: 4,
    name: "ROYAL OUD",
    subtitle: "Inspired by Arabian Oud",
    price: 520,
    notes: "Agarwood • Leather • Ambergris",
    image: "https://images.pexels.com/photos/258244/pexels-photo-258244.jpeg?auto=compress&cs=tinysrgb&w=800",
    bestseller: false,
    intensity: "Extra Parfum • 50ml"
  },
  {
    id: 5,
    name: "BLESSÉLLE",
    subtitle: "Signature Women Collection",
    price: 400,
    notes: "Jasmine • Peony • White Musk",
    image: "https://images.pexels.com/photos/11216292/pexels-photo-11216292.jpeg?auto=compress&cs=tinysrgb&w=800",
    bestseller: false,
    intensity: "Eau de Parfum • 50ml"
  },
  {
    id: 6,
    name: "WILD BLACK",
    subtitle: "Midnight Seduction",
    price: 480,
    notes: "Bergamot • Black Pepper • Vetiver",
    image: "https://images.pexels.com/photos/36834269/pexels-photo-36834269.jpeg?auto=compress&cs=tinysrgb&w=800",
    bestseller: true,
    intensity: "Eau de Parfum • 60ml"
  }
];

const PHONE = "0695254997";
const PHONE_DISPLAY = "069 525 4997";
const WHATSAPP_LINK = `https://wa.me/27${PHONE.substring(1)}`;

type CartItem = typeof PERFUMES[0] & { qty: number };

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [activeScent, setActiveScent] = useState<number | null>(null);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const addToCart = (p: typeof PERFUMES[0]) => {
    setCart(prev => {
      const found = prev.find(i => i.id === p.id);
      if (found) return prev.map(i => i.id === p.id ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { ...p, qty: 1 }];
    });
    setCartOpen(true);
  };

  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const count = cart.reduce((s, i) => s + i.qty, 0);

  const sendWhatsAppOrder = () => {
    const items = cart.map(c => `• ${c.name} x${c.qty} - R${c.price * c.qty}`).join('%0A');
    const msg = `Hello Bless Scent Perfumes,%0A%0AI would like to order:%0A${items}%0A%0ATotal: R${total}%0A%0APlease confirm availability. Thank you!`;
    window.open(`${WHATSAPP_LINK}?text=${msg}`, "_blank");
  };

  return (
    <div className="bg-[#070709] text-[#F5E8C8] selection:bg-[#DAB86A] selection:text-black font-[Montserrat] antialiased overflow-x-hidden">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600;700&family=Montserrat:wght@300;400;500;600&display=swap');
        .font-display { font-family: 'Cormorant Garamond', serif; }
        .font-body { font-family: 'Montserrat', sans-serif; }
        .gold-gradient { background: linear-gradient(100deg, #FBF0C4 0%, #E1BC85 30%, #C9A46A 55%, #8C6B3C 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .gold-bg { background: linear-gradient(100deg, #FBF0C4 0%, #E1BC85 30%, #C9A46A 60%, #9C7E4A 100%); }
        .gold-border { border-image: linear-gradient(90deg, #FBF0C4, #C9A46A) 1; }
        .shine { position: relative; overflow: hidden; }
        .shine::after { content:''; position:absolute; top:-50%; left:-50%; width:200%; height:200%; background: linear-gradient(120deg, transparent 20%, rgba(255,255,255,0.15) 50%, transparent 80%); transform: translateX(-100%) rotate(12deg); animation: shine 4.5s infinite; }
        @keyframes shine { 0%{ transform: translateX(-100%) rotate(12deg);} 60%{ transform: translateX(140%) rotate(12deg);} 100%{ transform: translateX(140%) rotate(12deg);} }
        .marquee { animation: marquee 28s linear infinite; }
        @keyframes marquee { from{ transform: translateX(0);} to{ transform: translateX(-50%);} }
      `}</style>

      {/* NAV */}
      <nav className={`fixed top-0 w-full z-40 transition-all duration-500 border-b ${scrolled ? "bg-black/80 backdrop-blur-xl border-[#C9A46A]/20 py-3" : "bg-transparent border-transparent py-5"}`}>
        <div className="mx-auto max-w-[1320px] px-6 md:px-10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full gold-bg flex items-center justify-center text-black font-display font-bold text-[18px]">B</div>
            <div className="leading-[1.1]">
              <div className="font-display text-[18px] md:text-[20px] tracking-[0.18em] font-semibold text-[#F5E8C8]">BLESS SCENT</div>
              <div className="font-body text-[9px] tracking-[0.35em] text-[#C9A46A] -mt-[1px]">PERFUMES</div>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-10 font-body text-[11px] tracking-[0.25em] text-[#C7B99E]">
            <a href="#collection" className="hover:text-[#F5E8C8] transition">COLLECTION</a>
            <a href="#story" className="hover:text-[#F5E8C8] transition">OUR STORY</a>
            <a href="#contact" className="hover:text-[#F5E8C8] transition">CONTACT</a>
          </div>

          <div className="flex items-center gap-3">
            <a href={`tel:${PHONE}`} className="hidden sm:flex items-center gap-2 border border-[#C9A46A]/30 px-4 py-2 rounded-full text-[11px] tracking-widest hover:border-[#C9A46A] transition">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
              {PHONE_DISPLAY}
            </a>
            <button onClick={() => setCartOpen(true)} className="relative h-10 w-10 rounded-full border border-[#C9A46A]/30 flex items-center justify-center hover:bg-white/5 transition">
              <span className="text-[16px]">⌖</span>
              {count > 0 && <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full gold-bg text-black text-[11px] font-bold flex items-center justify-center">{count}</span>}
            </button>
          </div>
        </div>
      </nav>

      {/* HERO with background logo */}
      <section className="relative min-h-[100svh] flex items-center justify-center overflow-hidden">
        {/* Background image - the logo as background, darkened */}
        <div className="absolute inset-0">
          <img src="./bless-scent-logo.jpg" alt="Bless Scent Background" className="w-full h-full object-cover opacity-[0.35] scale-[1.15]" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/70 to-[#070709]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_transparent_30%,_#070709_80%)]" />
        </div>

        {/* decorative gold glow */}
        <div className="pointer-events-none absolute top-[20%] left-1/2 -translate-x-1/2 h-[700px] w-[700px] rounded-full bg-[#C9A46A]/10 blur-[120px]" />

        <div className="relative z-10 mx-auto max-w-[1320px] px-6 md:px-10 pt-28 pb-14 w-full grid lg:grid-cols-[1.15fr_0.85fr] gap-10 items-center">
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-3 border border-[#C9A46A]/20 rounded-full px-4 py-1.5 bg-white/[0.03] backdrop-blur-md mb-8">
              <span className="h-[3px] w-[3px] rounded-full gold-bg" />
              <span className="font-body text-[10px] tracking-[0.35em] text-[#E1C68E]">INSPIRED BY LUXURY, MADE FOR YOU</span>
            </div>

            <h1 className="font-display leading-[0.9] tracking-[-0.02em]">
              <span className="block text-[18vw] lg:text-[110px] font-light text-[#F5E8C8]">Bless</span>
              <span className="block text-[18vw] lg:text-[110px] font-semibold gold-gradient -mt-2 lg:-mt-4">Scent</span>
            </h1>

            <p className="font-body mt-8 text-[15px] md:text-[16px] leading-[1.8] text-[#C7B99E] max-w-[520px] mx-auto lg:mx-0">
              Oil-based, long-lasting perfumes inspired by iconic designer fragrances. Crafted in South Africa for those who own their presence without saying a word.
            </p>

            <div className="mt-10 flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
              <a href="#collection" className="shine gold-bg text-black font-body text-[12px] tracking-[0.25em] font-semibold px-9 py-4 rounded-full hover:brightness-110 transition">EXPLORE COLLECTION</a>
              <a href={WHATSAPP_LINK} target="_blank" className="group border border-[#C9A46A]/30 rounded-full px-9 py-4 font-body text-[12px] tracking-[0.25em] flex items-center gap-3 hover:border-[#C9A46A] transition bg-white/[0.03] backdrop-blur">
                <span>WHATSAPP US</span>
                <span className="group-hover:translate-x-1 transition">→</span>
              </a>
            </div>

            <div className="mt-14 grid grid-cols-3 max-w-[420px] mx-auto lg:mx-0 divide-x divide-[#C9A46A]/15 border border-[#C9A46A]/15 rounded-2xl overflow-hidden bg-white/[0.02]">
              {[
                { k: "30+", v: "Scents" },
                { k: "12H+", v: "Long Lasting" },
                { k: "100%", v: "Oil Based" },
              ].map(s => (
                <div key={s.v} className="py-4 text-center">
                  <div className="font-display text-[24px] text-[#F5E8C8]">{s.k}</div>
                  <div className="font-body text-[10px] tracking-widest text-[#C9A46A]/70">{s.v}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right card - perfume highlight */}
          <div className="relative mx-auto w-full max-w-[460px] lg:max-w-none">
            <div className="relative rounded-[32px] border border-[#C9A46A]/20 bg-gradient-to-b from-white/[0.06] to-white/[0.01] backdrop-blur-xl p-3 shadow-[0_20px_80px_rgba(0,0,0,0.6)]">
              <div className="rounded-[24px] overflow-hidden bg-black relative aspect-[4/5]">
                <img src="https://images.pexels.com/photos/11216321/pexels-photo-11216321.jpeg?auto=compress&cs=tinysrgb&w=900" alt="Hero Perfume" className="h-full w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
                <div className="absolute bottom-0 p-7 w-full">
                  <div className="flex items-end justify-between">
                    <div>
                      <div className="font-body text-[10px] tracking-[0.3em] text-[#C9A46A]">BEST SELLER</div>
                      <div className="font-display text-[32px] text-white leading-none mt-1">BLESS NOIR</div>
                      <div className="font-body text-[11px] text-white/60 mt-1 tracking-wide">Oud • Amber • Musk</div>
                    </div>
                    <div className="text-right">
                      <div className="font-display text-[28px] text-[#F5E8C8]">R450</div>
                      <button onClick={() => addToCart(PERFUMES[0])} className="mt-2 h-10 w-10 rounded-full gold-bg text-black flex items-center justify-center">+</button>
                    </div>
                  </div>
                </div>
                <div className="absolute top-5 left-5 right-5 flex justify-between">
                  <span className="rounded-full bg-black/60 backdrop-blur px-3 py-1.5 text-[10px] tracking-widest border border-white/10">50ML EDP</span>
                  <span className="rounded-full gold-bg px-3 py-1.5 text-[10px] tracking-widest text-black font-semibold">IN STOCK</span>
                </div>
              </div>
              {/* floating contact */}
              <div className="absolute -bottom-6 -left-6 hidden md:flex items-center gap-3 rounded-full bg-[#0E0E0F] border border-[#C9A46A]/20 px-5 py-3 shadow-xl">
                <div className="h-10 w-10 rounded-full bg-[#1A1A1C] border border-[#C9A46A]/20 flex items-center justify-center text-[#C9A46A]">☎</div>
                <div>
                  <div className="font-body text-[10px] tracking-widest text-[#C9A46A]/70">BUSINESS CONTACT</div>
                  <a href={`tel:${PHONE}`} className="font-display text-[18px] tracking-wide">{PHONE_DISPLAY}</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Marquee */}
      <div className="relative border-y border-[#C9A46A]/15 bg-[#0D0D0E] overflow-hidden py-3">
        <div className="flex whitespace-nowrap marquee">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="flex items-center gap-8 font-body text-[11px] tracking-[0.4em] text-[#C9A46A]/60 pr-8">
              <span>INSPIRED BY LUXURY, MADE FOR YOU</span><span className="h-1 w-1 rounded-full bg-[#C9A46A]" />
              <span>FREE DELIVERY IN SA</span><span className="h-1 w-1 rounded-full bg-[#C9A46A]" />
              <span>LONG LASTING • OIL BASED</span><span className="h-1 w-1 rounded-full bg-[#C9A46A]" />
              <span>BLESS SCENT PERFUMES</span><span className="h-1 w-1 rounded-full bg-[#C9A46A]" />
              <span>DM TO ORDER {PHONE_DISPLAY}</span><span className="h-1 w-1 rounded-full bg-[#C9A46A]" />
            </div>
          ))}
        </div>
      </div>

      {/* Collection */}
      <section id="collection" className="mx-auto max-w-[1320px] px-6 md:px-10 py-24 md:py-28">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div>
            <div className="font-body text-[11px] tracking-[0.4em] text-[#C9A46A] flex items-center gap-3">
              <span className="h-px w-10 bg-[#C9A46A]/40" /> THE ATELIER
            </div>
            <h2 className="font-display text-[48px] md:text-[64px] leading-[0.95] mt-4">The Signature<br /><span className="gold-gradient italic font-light">Collection</span></h2>
          </div>
          <p className="font-body text-[14px] leading-[1.8] text-[#C7B99E]/80 max-w-[360px]">Each scent is an oil-based interpretation, crafted to last 12+ hours on skin. Luxury without the markup.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {PERFUMES.map(p => (
            <div key={p.id} onMouseEnter={() => setActiveScent(p.id)} onMouseLeave={() => setActiveScent(null)} className="group relative rounded-[24px] border border-white/[0.07] bg-gradient-to-b from-white/[0.05] to-white/[0.01] p-[1px] hover:border-[#C9A46A]/30 transition duration-500">
              <div className="rounded-[23px] bg-[#0D0D0E] overflow-hidden h-full flex flex-col">
                <div className="relative aspect-[4/3] overflow-hidden bg-black">
                  <img src={p.image} alt={p.name} className="w-full h-full object-cover group-hover:scale-[1.08] transition duration-[1.2s]" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0E] via-transparent to-transparent opacity-80" />
                  {p.bestseller && <div className="absolute top-4 left-4 rounded-full gold-bg px-3 py-1 text-[10px] tracking-widest text-black font-semibold">BESTSELLER</div>}
                  <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
                    <span className="text-[11px] tracking-widest font-body px-3 py-1.5 rounded-full bg-black/60 backdrop-blur border border-white/10">{p.intensity}</span>
                    <span className="font-display text-[18px]">R{p.price}</span>
                  </div>
                  <div className={`absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center transition ${activeScent === p.id ? "opacity-100" : "opacity-0 pointer-events-none"}`}>
                    <button onClick={() => addToCart(p)} className="gold-bg text-black rounded-full px-7 py-3 text-[11px] tracking-[0.2em] font-semibold">ADD TO BAG — R{p.price}</button>
                  </div>
                </div>
                <div className="p-5 flex-1 flex flex-col">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-display text-[22px] tracking-wide">{p.name}</h3>
                      <p className="font-body text-[11px] tracking-wide text-[#C9A46A]/70 mt-1">{p.subtitle}</p>
                    </div>
                    <button onClick={() => addToCart(p)} className="h-9 w-9 rounded-full border border-[#C9A46A]/20 flex items-center justify-center hover:bg-white/5">+</button>
                  </div>
                  <div className="mt-4 pt-4 border-t border-white/5 flex justify-between items-center">
                    <span className="font-body text-[10px] tracking-[0.2em] text-white/50">{p.notes}</span>
                    <span className="h-px flex-1 mx-3 bg-white/5" />
                    <span className="text-[#C9A46A] text-[14px]">✦</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Story */}
      <section id="story" className="relative border-y border-[#C9A46A]/10 bg-[#0B0B0C]">
        <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: `url(./bless-scent-logo.jpg)`, backgroundSize: '600px', backgroundRepeat: 'repeat', backgroundPosition: 'center' }} />
        <div className="mx-auto max-w-[1320px] px-6 md:px-10 py-20 md:py-28 grid lg:grid-cols-2 gap-12 items-center relative">
          <div className="relative">
            <div className="rounded-[32px] overflow-hidden border border-[#C9A46A]/15 aspect-[4/5] bg-black">
              <img src="https://images.pexels.com/photos/1961795/pexels-photo-1961795.jpeg?auto=compress&cs=tinysrgb&w=900" alt="Craft" className="w-full h-full object-cover opacity-80" onError={(e) => (e.currentTarget.style.display='none')} />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
            </div>
            <div className="absolute -bottom-8 -right-4 md:-right-8 rounded-[20px] bg-[#141415] border border-[#C9A46A]/20 p-6 max-w-[280px] shadow-2xl">
              <div className="font-display text-[44px] leading-none gold-gradient">100%</div>
              <div className="font-body text-[11px] tracking-[0.3em] text-[#F5E8C8]/70 mt-1">CUSTOMER SATISFACTION</div>
              <p className="font-body text-[12px] leading-[1.6] text-[#C7B99E]/70 mt-3">"Smells exactly like the original but lasts way longer. People stop me everywhere."</p>
              <div className="mt-3 font-body text-[10px] tracking-wide text-[#C9A46A]">— Thandi M., Verified Buyer</div>
            </div>
          </div>
          <div>
            <div className="font-body text-[11px] tracking-[0.4em] text-[#C9A46A]">OUR PHILOSOPHY</div>
            <h2 className="font-display text-[42px] md:text-[54px] leading-[0.95] mt-4">Luxury is a<br />feeling, not a<br /><span className="italic font-light gold-gradient">price tag.</span></h2>
            <div className="mt-8 space-y-5 font-body text-[14px] leading-[1.9] text-[#C7B99E]/80">
              <p>Bless Scent was born from a simple belief — everyone deserves to smell expensive. We source premium fragrance oils inspired by iconic houses and blend them at 40% concentration.</p>
              <p>That’s why our perfumes project for 12+ hours, not 2. We are proudly South African, small-batch, and obsessed with quality over quantity.</p>
            </div>
            <div className="mt-10 grid grid-cols-3 gap-6 border-t border-[#C9A46A]/15 pt-8">
              {[
                { title: "Oil Based", desc: "No alcohol burn" },
                { title: "Cruelty Free", desc: "Vegan & kind" },
                { title: "Refillable", desc: "Bring bottle back" },
              ].map(f => (
                <div key={f.title}>
                  <div className="font-display text-[18px] text-[#F5E8C8]">{f.title}</div>
                  <div className="font-body text-[11px] text-[#C9A46A]/60 mt-1">{f.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="mx-auto max-w-[1320px] px-6 md:px-10 py-20 md:py-28">
        <div className="rounded-[32px] border border-[#C9A46A]/15 bg-gradient-to-br from-[#141412] to-[#0B0B0C] overflow-hidden grid lg:grid-cols-[1.1fr_0.9fr]">
          <div className="p-10 md:p-14">
            <div className="inline-flex items-center gap-2 rounded-full border border-[#C9A46A]/20 px-3 py-1 bg-white/[0.02]">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-body text-[10px] tracking-[0.3em] text-[#C9A46A]">AVAILABLE NOW • 08:00 - 20:00</span>
            </div>
            <h2 className="font-display text-[44px] md:text-[56px] leading-[0.9] mt-8">Ready to<br />find your<br /><span className="gold-gradient">signature?</span></h2>
            <p className="font-body text-[14px] leading-[1.8] text-[#C7B99E]/70 mt-6 max-w-[420px]">Chat to us directly. We’ll help you match your favourite designer scent to a Bless Scent version, plus give you delivery info.</p>

            <div className="mt-10 space-y-4">
              <a href={`tel:${PHONE}`} className="group flex items-center gap-4 rounded-2xl bg-[#0E0E0F] border border-[#C9A46A]/10 p-4 hover:border-[#C9A46A]/30 transition">
                <div className="h-12 w-12 rounded-full gold-bg flex items-center justify-center text-black text-[18px]">✆</div>
                <div className="flex-1">
                  <div className="font-body text-[10px] tracking-[0.3em] text-[#C9A46A]/70">CALL / WHATSAPP DIRECTLY</div>
                  <div className="font-display text-[24px] tracking-wide mt-0.5">{PHONE_DISPLAY}</div>
                </div>
                <div className="h-9 w-9 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-white/10">→</div>
              </a>
              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-2xl bg-[#0E0E0F] border border-white/5 p-4">
                  <div className="font-body text-[10px] tracking-widest text-white/40">LOCATION</div>
                  <div className="font-body text-[13px] mt-2 leading-[1.5] text-[#C7B99E]">South Africa<br />Nationwide Delivery</div>
                </div>
                <div className="rounded-2xl bg-[#0E0E0F] border border-white/5 p-4">
                  <div className="font-body text-[10px] tracking-widest text-white/40">PAYMENT</div>
                  <div className="font-body text-[13px] mt-2 leading-[1.5] text-[#C7B99E]">Cash on Delivery<br />EFT / E-Wallet</div>
                </div>
              </div>
            </div>
          </div>
          <div className="relative bg-black p-1">
            <div className="h-full rounded-[24px] overflow-hidden bg-[#0B0B0C] border border-white/5 relative flex flex-col">
              <img src="./bless-scent-logo.jpg" alt="Logo Background" className="absolute inset-0 w-full h-full object-cover opacity-[0.18]" />
              <div className="relative p-10 md:p-10 flex-1 flex flex-col justify-center">
                <div className="mx-auto w-full max-w-[360px] rounded-[20px] bg-[#141414]/80 backdrop-blur-xl border border-[#C9A46A]/20 p-6">
                  <div className="font-body text-[11px] tracking-[0.3em] text-[#C9A46A] text-center">QUICK ORDER VIA WHATSAPP</div>
                  <div className="mt-6 space-y-3">
                    <input placeholder="Your Name" className="w-full rounded-full bg-black/60 border border-white/10 px-5 py-3.5 font-body text-[13px] outline-none focus:border-[#C9A46A]/40" />
                    <input placeholder="Favourite Designer Scent?" className="w-full rounded-full bg-black/60 border border-white/10 px-5 py-3.5 font-body text-[13px] outline-none focus:border-[#C9A46A]/40" />
                    <textarea placeholder="Message..." rows={3} className="w-full rounded-2xl bg-black/60 border border-white/10 px-5 py-3.5 font-body text-[13px] outline-none focus:border-[#C9A46A]/40 resize-none" />
                    <a href={`${WHATSAPP_LINK}?text=Hi%20Bless%20Scent!%20I%20want%20to%20order.`} target="_blank" className="flex w-full justify-center rounded-full gold-bg py-3.5 text-[11px] tracking-[0.25em] font-semibold text-black">SEND ON WHATSAPP</a>
                    <div className="text-center font-body text-[10px] text-white/40 tracking-wide">REPLIES WITHIN 15 MIN • {PHONE_DISPLAY}</div>
                  </div>
                </div>
              </div>
              <div className="relative border-t border-white/5 p-5 flex items-center justify-between">
                <div className="font-display text-[14px] tracking-[0.2em]">BLESS SCENT PERFUMES</div>
                <div className="font-body text-[10px] tracking-[0.2em] text-[#C9A46A]/60">EST. 2024 • SA</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#C9A46A]/10 py-12">
        <div className="mx-auto max-w-[1320px] px-6 md:px-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3 opacity-60">
            <div className="h-8 w-8 rounded-full border border-[#C9A46A]/30 flex items-center justify-center font-display font-bold text-[#C9A46A]">B</div>
            <div className="font-body text-[11px] tracking-[0.25em]">© 2025 BLESS SCENT PERFUMES • INSPIRED BY LUXURY, MADE FOR YOU.</div>
          </div>
          <div className="flex items-center gap-6 font-body text-[11px] tracking-[0.2em] text-[#C7B99E]/60">
            <a href={`tel:${PHONE}`} className="hover:text-[#C9A46A]">{PHONE_DISPLAY}</a>
            <a href={WHATSAPP_LINK} target="_blank" className="hover:text-[#C9A46A]">WHATSAPP</a>
            <a href="#collection" className="hover:text-[#C9A46A]">SHOP</a>
          </div>
        </div>
      </footer>

      {/* Cart Drawer */}
      <div className={`fixed inset-0 z-[60] transition ${cartOpen ? "visible" : "invisible"}`}>
        <div className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition ${cartOpen ? "opacity-100" : "opacity-0"}`} onClick={() => setCartOpen(false)} />
        <div className={`absolute right-0 top-0 h-full w-full max-w-[420px] bg-[#0E0E0F] border-l border-[#C9A46A]/15 transition-transform duration-500 ${cartOpen ? "translate-x-0" : "translate-x-full"}`}>
          <div className="p-7 flex flex-col h-full">
            <div className="flex items-center justify-between">
              <div className="font-display text-[28px]">Your Bag <span className="text-[#C9A46A]">({count})</span></div>
              <button onClick={() => setCartOpen(false)} className="h-9 w-9 rounded-full border border-white/10 flex items-center justify-center">✕</button>
            </div>
            <div className="mt-2 font-body text-[11px] tracking-[0.3em] text-[#C9A46A]/60">SECURE WHATSAPP CHECKOUT</div>

            <div className="mt-8 flex-1 overflow-auto space-y-4 pr-1">
              {cart.length === 0 ? (
                <div className="h-[60%] flex flex-col items-center justify-center text-center">
                  <div className="h-20 w-20 rounded-full bg-white/[0.04] border border-[#C9A46A]/10 flex items-center justify-center text-[28px]">⌖</div>
                  <div className="font-display text-[22px] mt-5">Bag is empty</div>
                  <div className="font-body text-[13px] text-white/50 mt-2 max-w-[240px]">Add your favourite Bless Scent to start your order.</div>
                  <a href="#collection" onClick={() => setCartOpen(false)} className="mt-6 rounded-full border border-[#C9A46A]/30 px-6 py-2.5 text-[11px] tracking-widest">SHOP COLLECTION</a>
                </div>
              ) : cart.map(item => (
                <div key={item.id} className="rounded-2xl bg-white/[0.03] border border-white/5 p-3 flex gap-4">
                  <img src={item.image} alt={item.name} className="h-20 w-20 rounded-xl object-cover" />
                  <div className="flex-1">
                    <div className="font-display text-[16px] leading-none">{item.name}</div>
                    <div className="font-body text-[10px] text-[#C9A46A]/60 mt-1 tracking-wide">{item.notes}</div>
                    <div className="mt-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <button onClick={() => setCart(c => c.map(i => i.id === item.id ? { ...i, qty: Math.max(1, i.qty - 1) } : i))} className="h-7 w-7 rounded-full bg-white/5">−</button>
                        <span className="font-body text-[12px] w-6 text-center">{item.qty}</span>
                        <button onClick={() => setCart(c => c.map(i => i.id === item.id ? { ...i, qty: i.qty + 1 } : i))} className="h-7 w-7 rounded-full bg-white/5">+</button>
                      </div>
                      <div className="font-display text-[16px]">R{item.price * item.qty}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {cart.length > 0 && (
              <div className="border-t border-white/10 pt-6 space-y-4">
                <div className="flex justify-between font-body text-[12px] tracking-wide text-white/60">
                  <span>SUBTOTAL</span>
                  <span className="font-display text-[20px] text-white">R{total}</span>
                </div>
                <button onClick={sendWhatsAppOrder} className="w-full gold-bg rounded-full py-4 text-black font-semibold tracking-[0.2em] text-[12px] shine">ORDER ON WHATSAPP →</button>
                <div className="text-center font-body text-[10px] text-white/40">You will be redirected to WhatsApp with your order • {PHONE_DISPLAY}</div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Floating WA */}
      <a href={WHATSAPP_LINK} target="_blank" className="fixed bottom-5 right-5 z-30 h-14 w-14 rounded-full gold-bg shadow-[0_8px_30px_rgba(201,164,106,0.4)] flex items-center justify-center text-black text-[22px] hover:scale-105 transition md:bottom-7 md:right-7">
        <span>✦</span>
      </a>
    </div>
  );
}
