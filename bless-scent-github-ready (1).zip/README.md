# Bless Scent Perfumes

GitHub-ready React + Vite website exported from Arena.

## Run locally

```bash
npm ci
npm run dev
```

## Build

```bash
npm run build
```

## GitHub Pages

Push the repository to GitHub on the `main` branch. The included GitHub Actions workflow builds the site and deploys the `dist` folder to GitHub Pages.

In GitHub:
1. Open **Settings → Pages**.
2. Under **Build and deployment**, select **GitHub Actions**.
3. Push to `main` (or run the workflow manually).
4. Open the URL shown under the `github-pages` deployment.

The Vite `base: './'` setting allows the site to work when hosted under a repository path such as `/bless-scent-perfumes/`.
